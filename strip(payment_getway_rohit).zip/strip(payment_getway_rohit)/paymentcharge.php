
<?php

/*session start (session username, and session username set*/


  require_once('connection.php');
/*config file call*/
  $token  = $_POST['stripeToken'];           /*email token generate */
  $email  = $_POST['stripeEmail'];           /* strip email show */

  $customer = \Stripe\Customer::create(array(
      'email' => $email,
      'source'  => $token
  ));

  $charge = \Stripe\Charge::create(array(
      'customer' => $customer->id,
      'amount'   => 'totalAmount',             /*total amount echo */        
      'currency' => 'inr'
  ));                               /*change currency*/   


                                              /*echo the $charge */
?>
 