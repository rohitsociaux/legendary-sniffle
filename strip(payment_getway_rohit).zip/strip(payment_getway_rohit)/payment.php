         <!--step no.=> file name set in action  -->
         <!-- step 2=> testing keys add in strip -->
         <!-- step 3=> data-amount set fatch to row in query -->
         <!-- these code show the pay button in pop up  -->
<!--  data-amount=100; (echo the your total amount button show your amount) -->
          <form action="paymentcharge.php" method="POST">
          <script
          src="https://checkout.stripe.com/checkout.js" class="stripe-button"
          data-key="pk_test_XUg0EdVmeOHo12A43pCTG1o7"
          data-amount=100;           
          data-currency=inr
          data-name="American STEM Institute"
          data-description="Payment"
          data-image="http://americansteminstitute.org/images/Asi_header_New.png"
          data-locale="auto">
          </script>
     </form>