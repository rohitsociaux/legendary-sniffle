<?php
                                      /*file name set vendor folder=>autoload.php*/
require_once('vendor/autoload.php');
                                          /*testing keys set in strip*/
$stripe = array(
  "secret_key"      => "sk_test_Yc3qxVh0qUNP1OUby5Dwg8ti",
  "publishable_key" => "pk_test_XUg0EdVmeOHo12A43pCTG1o7"     /*( two  keys are submit sk_test and pk_test key) call th testing keys */
);
                                                                   
\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>